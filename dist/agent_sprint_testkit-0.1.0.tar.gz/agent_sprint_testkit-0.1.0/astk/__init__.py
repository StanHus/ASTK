"""
AgentSprint TestKit (ASTK) - A CI-first behavioural-coverage and regression-gating framework
"""

__version__ = "0.1.0"
